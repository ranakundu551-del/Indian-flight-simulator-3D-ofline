India Flight Simulator - Android starter project

This is a small offline Android WebView starter prototype. It is NOT the completed simulator.
It does not yet contain an accurate official 3D India map, real aircraft models, airport database, or 100 complete missions.

Upload this ZIP to the root of your GitHub repository with the exact filename:
IndiaFlightSimulatorProject.zip

Then replace .github/workflows/build.yml with the workflow code provided in the ChatGPT instructions.
